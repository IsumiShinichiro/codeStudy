export default function () {
  return {
    evaluate: () => {},
  };
}
